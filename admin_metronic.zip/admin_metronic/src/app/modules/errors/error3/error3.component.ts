import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error3',
  templateUrl: './error3.component.html',
})
export class Error3Component implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
