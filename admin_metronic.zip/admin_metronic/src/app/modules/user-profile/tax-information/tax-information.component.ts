import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tax-information',
  templateUrl: './tax-information.component.html',
  styleUrls: ['./tax-information.component.scss']
})
export class TaxInformationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
