import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngbootstrap',
  templateUrl: './ngbootstrap.component.html',
})
export class NgbootstrapComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
